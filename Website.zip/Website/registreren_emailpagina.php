<?php
session_Start();
include_once('functies.php');
include_once('database.php');
$headerEmailPagina = "Location: http://iproject2.icasites.nl/verstuurmail.php";
$_SESSION['Emailadres'] = "";
$_SESSION['emailErr'] = "";

if (isset($_POST['verstuurmail'])) {
   $_SESSION['Emailadres'] = test_invoer($_POST['Emailadres']);
   $tellingemailadres = vergelijkloginwaarde("Emailadres", $_SESSION['Emailadres'], $dbh);

    if (empty($_SESSION['Emailadres'])) {
        $_SESSION['emailErr'] = "Email is verplicht";
    } elseif (!$tellingemailadres == 0) {
        $_SESSION['emailErr'] = "Dit email-adres is al in gebruik";
    } elseif (filter_var($_SESSION['Emailadres'], FILTER_VALIDATE_EMAIL) == false) {
        $_SESSION['emailErr'] = "Vul een correct geformuleerd email-adres in";
    } else {
        header($headerEmailPagina);
    }
}


include_once("header.php");
?>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Website Paginas</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="assets/bootstrap/css/styles.css">
</head>

<body style="background-color: #3a3a3a;">
<
<main style="min-height: 52.5vh;margin-right: 10vw;margin-left: 10vw;">
    <div class="container text-center" style="padding: 4em;">
        <h2 style="margin: 1ex;color: #ffffff;">Registreren</h2>
        <form style="width: 100%;padding: 2em;" method="post" action="registreren_emailpagina.php">
            <h5 class="text-center text-sm-center text-md-center text-lg-center text-xl-center" >Vul jouw email-adres in*</h5>
            <h5 class="text-center text-sm-center text-md-center text-lg-center text-xl-center foutmeldingTekst"> <?php echo $_SESSION['emailErr'];?></h5>
            <div class="d-flex d-sm-flex d-md-flex d-lg-flex d-xl-flex justify-content-center align-items-center flex-wrap flex-sm-wrap flex-md-nowrap flex-lg-nowrap justify-content-xl-center align-items-xl-center flex-xl-nowrap"
                 style="margin: 1em 0em;"><input
                        class="form-control" type="text" name="Emailadres" id="Emailadres" placeholder="Email"
                        style="width: 75%;background-color: #c5ae91;"></div>
            <button class="btn btn-primary text-center" data-bs-hover-animate="pulse" type="submit" name="verstuurmail"
                    style="width: 100%;margin-top: 1em;background-color: #ffb357;">Registreer
            </button>
        </form>
    </div>
</main>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/js/bs-animation.js"></script>
</body>
<?php include_once("footer.php");?>