<?php
$message = "wrong answer";
echo "<script type='text/javascript'>alert('$message');</script>";