<?php
?>

<div class="footer-dark">
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-md-3 item">
                    <h3>Services</h3>
                    <ul>
                        <li><a href="#">Veilingen</a></li>
                        <li><a href="#">Over Ons</a></li>
                        <li><a href="#">Rubrieken</a></li>
                    </ul>
                </div>
                <div class="col-md-6 item text">
                    <h3>EenmaalAndermaal</h3>
                    <p>Praesent sed lobortis mi. Suspendisse vel placerat ligula. Vivamus ac sem lacus. Ut vehicula rhoncus elementum. Etiam quis tristique lectus. Aliquam in arcu eget velit pulvinar dictum vel in justo.</p>
                </div>
            </div>
            <p class="copyright">EenmaalAndermaal © 2019</p>
        </div>
    </footer>
</div>
<div></div>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>
