<?php

$dbname = "iproject2";
$username = "iproject2";
$pw = "k1kQ2Ynu4M";

$serverName = "mssql2.iproject.icasites.nl";
$connectionInfo = array( "Database"=>"$dbname",  "UID"=>"$username", "PWD"=>"$pw");
$dbh = sqlsrv_connect( $serverName, $connectionInfo);



try {
    $dbh = new PDO ("sqlsrv:Server=$serverName;Database=$dbname;
			ConnectionPooling=0", "$username", "$pw");
    if(!$dbh) {
        throw new Exception();
    }
}
catch(Exception $e){

    $_SESSION['foutmelding'] = "Fout: kan geen verbinding maken met de server, probeer het later opnieuw, foutmelding: $e";
    echo $_SESSION['foutmelding'];
}

if(!isset($_SESSION))
{
    session_start();
}




if(!$dbh)
{
    echo "Connection could not be established.<br />";
    die( print_r( sqlsrv_errors(), true));
}

$dsn = "sqlsrv:Server=mssql.iproject.icasites.nl,1433;Database=iproject";



/* dit is voor de localhost testdatabase
$hostname = "(local)";
$dbname = "EenmaalAndermaal";
$username = "sa";
$pw = "QrpQ5736";

try {
    $dbh = new PDO ("sqlsrv:Server=$hostname;Database=$dbname;
			ConnectionPooling=0", "$username", "$pw");
    if (!$dbh) {
        throw new Exception();
    }
} catch (Exception $e) {

    $_SESSION['foutmelding'] = "Fout: kan geen verbinding maken met de server, probeer het later opnieuw";
    echo $_SESSION['foutmelding'];
}

if (!isset($_SESSION)) {
    session_start();
}*/



