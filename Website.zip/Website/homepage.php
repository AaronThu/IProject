<?php
include_once("header.php");
?>

<head>

</head>

<body class="background">
<div style="background-color: #4b4c4d;">
    <div class="container">
        <div class="row">
            <div class="col">
                <h1 class="text-center" style="color: #a9976a;">Speciaal voor u</h1>
            </div>
        </div>
    </div>
</div>
<div>
    <div class="container" style="background-color: #4b4c4d;filter: saturate(100%);">
        <div class="carousel slide" data-ride="carousel" id="carousel-1">
            <div class="carousel-inner" role="listbox">
                <div class="carousel-item">
                    <div class="card-deck" style="background-color: #4b4c4d;">
                        <div class="card"><img class="card-img-top w-100 d-block" src="assets/img/HP_laptop.jpg">
                            <div class="card-body" style="background-color: #d6d6d6;">
                                <h4 class="card-title">Title</h4>
                                <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p><button class="btn btn-primary" type="button"
                                                                                                                                                                                                                                      style="background-color: #a9976a;">Bied mee!</button></div>
                        </div>
                        <div class="card" style="background-color: #d6d6d6;"><img class="card-img-top w-100 d-block" src="assets/img/HP_laptop.jpg">
                            <div class="card-body" style="background-color: #d6d6d6;">
                                <h4 class="card-title">Title</h4>
                                <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p><button class="btn btn-primary" type="button"
                                                                                                                                                                                                                                      style="background-color: #a9976a;">Bied mee!</button></div>
                        </div>
                        <div class="card"><img class="card-img-top w-100 d-block" src="assets/img/HP_laptop.jpg">
                            <div class="card-body" style="background-color: #d6d6d6;">
                                <h4 class="card-title">Title</h4>
                                <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p><button class="btn btn-primary" type="button"
                                                                                                                                                                                                                                      style="background-color: #a9976a;">Bied mee!</button></div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="card-deck" style="background-color: #4b4c4d;">
                        <div class="card"><img class="card-img-top w-100 d-block" src="assets/img/Boeing_foto.jpg">
                            <div class="card-body" style="background-color: #d6d6d6;">
                                <h4 class="card-title">Title</h4>
                                <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p><button class="btn btn-primary" type="button"
                                                                                                                                                                                                                                      style="background-color: #a9976a;">Bied mee!</button></div>
                        </div>
                        <div class="card"><img class="card-img-top w-100 d-block" src="assets/img/Boeing_foto.jpg">
                            <div class="card-body" style="background-color: #d6d6d6;">
                                <h4 class="card-title">Title</h4>
                                <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p><button class="btn btn-primary" type="button"
                                                                                                                                                                                                                                      style="background-color: #a9976a;">Bied mee!</button></div>
                        </div>
                        <div class="card"><img class="card-img-top w-100 d-block" src="assets/img/Boeing_foto.jpg">
                            <div class="card-body" style="background-color: #d6d6d6;">
                                <h4 class="card-title">Title</h4>
                                <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p><button class="btn btn-primary" type="button"
                                                                                                                                                                                                                                      style="background-color: #a9976a;">Bied mee!</button></div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item active">
                    <div class="card-deck" style="background-color: #4b4c4d;">
                        <div class="card"><img class="card-img-top w-100 d-block" src="assets/img/Rollator_foto.jpg">
                            <div class="card-body" style="background-color: #d6d6d6;">
                                <h4 class="card-title">Title</h4>
                                <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p><button class="btn btn-primary" type="button"
                                                                                                                                                                                                                                      style="background-color: #a9976a;">Bied mee!</button></div>
                        </div>
                        <div class="card"><img class="card-img-top w-100 d-block" src="assets/img/Rollator_foto.jpg">
                            <div class="card-body" style="background-color: #d6d6d6;">
                                <h4 class="card-title">Title</h4>
                                <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p><button class="btn btn-primary" type="button"
                                                                                                                                                                                                                                      style="background-color: #a9976a;">Bied mee!</button></div>
                        </div>
                        <div class="card"><img class="card-img-top w-100 d-block" src="assets/img/Rollator_foto.jpg">
                            <div class="card-body" style="background-color: #d6d6d6;">
                                <h4 class="card-title">Title</h4>
                                <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p><button class="btn btn-primary" type="button"
                                                                                                                                                                                                                                      style="background-color: #a9976a;">Bied mee!</button></div>
                        </div>
                    </div>
                </div>
            </div>
            <div><a class="carousel-control-prev" href="#carousel-1" role="button" data-slide="prev" style="background-color: #989898;width: 40px;"><span class="carousel-control-prev-icon"></span><span class="sr-only">Previous</span></a><a class="carousel-control-next"
                                                                                                                                                                                                                                                href="#carousel-1" role="button" data-slide="next" style="background-color: #989898;width: 40px;"><span class="carousel-control-next-icon"></span><span class="sr-only">Next</span></a></div>
            <ol class="carousel-indicators">
                <li data-target="#carousel-1" data-slide-to="0"></li>
                <li data-target="#carousel-1" data-slide-to="1"></li>
                <li data-target="#carousel-1" data-slide-to="2" class="active"></li>
            </ol>
        </div>
    </div>
</div>
<div class="col" style="background-color: #4b4c4d;">
    <h1 class="text-center" style="background-color: #4b4c4d;color: #a9976a;">Anderen bekeken ook</h1>
</div>
<div class="footer-clean" style="background-color: #4b4c4d;color: #ffffff;">
    <div class="container">
        <div class="carousel slide" data-ride="carousel" id="carousel-9">
            <div class="carousel-inner" role="listbox">
                <div class="carousel-item active">
                    <div class="card-deck" style="color: #4b4c4d;">
                        <div class="card"><img class="card-img-top w-100 d-block" src="assets/img/B&D_foto.jpg">
                            <div class="card-body" style="color: #4b4c4d;background-color: #d6d6d6;">
                                <h4 class="card-title">Bladblazert</h4>
                                <p class="card-text" style="color: #4b4c4d;">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p><button class="btn btn-primary" type="button"
                                                                                                                                                                                                                                                              style="background-color: #a9976a;">Bied mee!</button></div>
                        </div>
                        <div class="card"><img class="card-img-top w-100 d-block align-self-center" src="assets/img/B&D_foto.jpg">
                            <div class="card-body" style="background-color: #d6d6d6;">
                                <h4 class="card-title">Blaasmachine met zak</h4>
                                <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p><button class="btn btn-primary" type="button"
                                                                                                                                                                                                                                      style="background-color: #a9976a;">Bied mee!</button></div>
                        </div>
                        <div class="card"><img class="card-img-top w-100 d-block" src="assets/img/B&D_foto.jpg">
                            <div class="card-body" style="background-color: #d6d6d6;">
                                <h4 class="card-title">Zuigmachine met blazert<br></h4>
                                <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p><button class="btn btn-primary" type="button"
                                                                                                                                                                                                                                      style="background-color: #a9976a;">Bied mee!</button></div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="card-deck" style="color: #4b4c4d;">
                        <div class="card"><img class="card-img-top w-100 d-block" src="assets/img/ferrari_foto.jpg">
                            <div class="card-body" style="background-color: #d6d6d6;">
                                <h4 class="card-title">Dikke BMW</h4>
                                <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p><button class="btn btn-primary" type="button"
                                                                                                                                                                                                                                      style="background-color: #a9976a;">Bied mee!</button></div>
                        </div>
                        <div class="card"><img class="card-img-top w-100 d-block" src="assets/img/ferrari_foto.jpg">
                            <div class="card-body" style="background-color: #d6d6d6;">
                                <h4 class="card-title">Mooie auto</h4>
                                <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p><button class="btn btn-primary" type="button"
                                                                                                                                                                                                                                      style="background-color: #a9976a;">Bied mee!</button></div>
                        </div>
                        <div class="card"><img class="card-img-top w-100 d-block" src="assets/img/ferrari_foto.jpg">
                            <div class="card-body" style="background-color: #d6d6d6;">
                                <h4 class="card-title">Kekke Ferrari</h4>
                                <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p><button class="btn btn-primary" type="button"
                                                                                                                                                                                                                                      style="background-color: #a9976a;">Bied mee!</button></div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="card-deck" style="color: #4b4c4d;">
                        <div class="card"><img class="card-img-top w-100 d-block" src="assets/img/Iphone_foto.jpg">
                            <div class="card-body" style="background-color: #d6d6d6;">
                                <h4 class="card-title">EIFOON</h4>
                                <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p><button class="btn btn-primary" type="button"
                                                                                                                                                                                                                                      style="background-color: #a9976a;">Bied mee!</button></div>
                        </div>
                        <div class="card"><img class="card-img-top w-100 d-block" src="assets/img/Iphone_foto.jpg">
                            <div class="card-body" style="background-color: #d6d6d6;">
                                <h4 class="card-title">Iphone</h4>
                                <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p><button class="btn btn-primary" type="button"
                                                                                                                                                                                                                                      style="background-color: #a9976a;">Bied mee!</button></div>
                        </div>
                        <div class="card"><img class="card-img-top w-100 d-block" src="assets/img/Iphone_foto.jpg">
                            <div class="card-body" style="background-color: #d6d6d6;">
                                <h4 class="card-title">IPhone</h4>
                                <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p><button class="btn btn-primary" type="button"
                                                                                                                                                                                                                                      style="background-color: #a9976a;">Bied mee!</button></div>
                        </div>
                    </div>
                </div>
            </div>
            <div><a class="carousel-control-prev" href="#carousel-9" role="button" data-slide="prev" style="background-color: #989898;width: 40px;height: 405px;"><span class="carousel-control-prev-icon"></span><span class="sr-only">Previous</span></a>
                <a
                    class="carousel-control-next" href="#carousel-9" role="button" data-slide="next" style="background-color: #989898;width: 40px;"><span class="carousel-control-next-icon"></span><span class="sr-only">Next</span></a>
            </div>
            <ol class="carousel-indicators">
                <li data-target="#carousel-9" data-slide-to="0" class="active"></li>
                <li data-target="#carousel-9" data-slide-to="1"></li>
                <li data-target="#carousel-9" data-slide-to="2"></li>
            </ol>
        </div>
    </div>
</div>
</body>
<script src="assets/bootstrap/js/jquery.min2"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>

<?php include_once("footer.php") ?>